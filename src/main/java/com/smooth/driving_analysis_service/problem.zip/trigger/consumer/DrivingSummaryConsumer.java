package com.smooth.driving_analysis_service.trigger.consumer;

import com.smooth.driving_analysis_service.trigger.dto.DrivingSummaryV1;
import com.smooth.driving_analysis_service.trigger.service.DrivingSummaryConsumerService;
import com.smooth.driving_analysis_service.global.redis.RedisKeys;
import com.smooth.driving_analysis_service.trigger.util.DrivingSummaryParser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.stream.StreamListener;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Slf4j
@Component
@RequiredArgsConstructor
public class DrivingSummaryConsumer implements StreamListener<String, MapRecord<String, Object, Object>> {

    private final DrivingSummaryConsumerService service;
    private final StringRedisTemplate stringRedisTemplate;

    @Value("${redis.stream.driving.name:driving-analysis-stream}")
    private String streamName;

    @Value("${redis.stream.driving.group:driving-analyzer-group}")
    private String groupName;

    // 중복 처리 키 TTL (예: 7일)
    private static final Duration DUP_TTL = Duration.ofDays(7);

    @Override
    public void onMessage(MapRecord<String, Object, Object> message) {
        String entryId = message.getId().getValue();

        try {
            DrivingSummaryV1 dto = DrivingSummaryParser.parse(message);
            dto.validateForProcessing();

            // 중복 처리: processed:trip:{drivingId} 키로 SETNX
            String dedupKey = RedisKeys.processedTrip(dto.getDrivingId());
            Boolean firstSeen = stringRedisTemplate.opsForValue().setIfAbsent(dedupKey, entryId, DUP_TTL);
            if (firstSeen == null || !firstSeen) {
                log.debug("skip duplicate trip {}", dto.getDrivingId());
                ack(message);
                return;
            }

            // 비즈니스 처리 (DB write, milestone append, 15개면 report-trigger 발행 등)
            service.handle(dto);

            // 정상 처리 후 ACK
            ack(message);
            log.debug("ACK {}", entryId);

        } catch (IllegalArgumentException ex) {
            // 필수값 누락 등 → 로그 남기고 ACK 해서 소비 완료(재시도 불필요)
            log.error("Failed to process {}: {}", entryId, ex.getMessage(), ex);
            ack(message);
        } catch (Exception ex) {
            // 시스템 에러 → 로그만 남김 (ACK 하지 않으면 PENDING 상태라 모니터링 가능)
            log.error("Unexpected error while processing {}: {}", entryId, ex.getMessage(), ex);
            // 정책에 따라 ACK 여부 조정 가능
        }
    }

    private void ack(MapRecord<String, Object, Object> message) {
        try {
            // acknowledge(group, recordId)
            stringRedisTemplate.opsForStream().acknowledge(streamName, groupName, message.getId());
        } catch (DataAccessException e) {
            log.warn("ACK failed for {}: {}", message.getId().getValue(), e.getMessage());
        }
    }
}
